---------------------------------------
 Drake NPC Mod for BG:EE by Artemius_I
---------------------------------------

-----------------------
 Introduction & Details
-----------------------

	STR: 17
	DEX: 16
	CON: 16
	INT: 11
	WIS: 15
	CHA: 10
	Total: 85

�Tyr�s buttocks, what I wouldn�t do for a warm fire and a stiff drink right now�� - Drake

Drake Caulfield is a priest of Tyr in his mid-thirties and a recruit for the Radiant Heart auxiliary. Unlike others of his faith, he is sarcastic, irreverent and cynical with a crude sense of humor. Despite that, he has a strong sense of faith in his own way and holds a personal grudge against the cruel and unjust.

He can be found in Beregost at the Burning Wizard Inn and will offer his services so you may work together to slay the evil priest Bassilus.

-----------------------
 Installation
-----------------------

Unzip the files into your Baldur's Gate: Enhanced Edition folder (usually C:/Program Files/Baldur's Gate Enhanced Edition/Data/00766 or /00806 for SoD) and run Setup-Drake.exe

-----------------------
 Friendship
-----------------------

Drake will talk to the player character so long as the party maintains a reputation above 12. A player character of either gender and any race may flirt with him, but his receptiveness will vary and he has no interest in beginning a relationship during BG1. Despite that, he may be willing to consider it for the future if he finds you compatible.

-----------------------
 Credits
-----------------------

Author: Artemius_I
Portrait: Lava Del'Vortel
Alternative Portrait: NWN Vault
Voicing: BillyYank

----------------------
 Change Log
----------------------

v0.1 BETA
 - initial release